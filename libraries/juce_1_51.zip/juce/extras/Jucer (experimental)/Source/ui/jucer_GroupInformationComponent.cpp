/*
  ==============================================================================

   This file is part of the JUCE library - "Jules' Utility Class Extensions"
   Copyright 2004-9 by Raw Material Software Ltd.

  ------------------------------------------------------------------------------

   JUCE can be redistributed and/or modified under the terms of the GNU General
   Public License (Version 2), as published by the Free Software Foundation.
   A copy of the license is included in the JUCE distribution, or can be found
   online at www.gnu.org/licenses.

   JUCE is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
   A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

  ------------------------------------------------------------------------------

   To release a closed-source product which uses JUCE, commercial licenses are
   available: visit www.rawmaterialsoftware.com/juce for more information.

  ==============================================================================
*/

#include "jucer_GroupInformationComponent.h"


//==============================================================================
GroupInformationComponent::GroupInformationComponent (const Project::Item& item_)
    : item (item_)
{
    addAndMakeVisible (list = new ListBox (String::empty, this));
    list->updateContent();
    list->setRowHeight (20);
    item.getNode().addListener (this);
}

GroupInformationComponent::~GroupInformationComponent()
{
    item.getNode().removeListener (this);
    deleteAllChildren();
}

void GroupInformationComponent::resized()
{
    list->setSize (getWidth(), getHeight());
}

int GroupInformationComponent::getNumRows()
{
    return item.getNumChildren();
}

void GroupInformationComponent::paintListBoxItem (int rowNumber, Graphics& g, int width, int height, bool rowIsSelected)
{
}

//==============================================================================
void GroupInformationComponent::valueTreePropertyChanged (ValueTree& treeWhosePropertyHasChanged, const var::identifier& property)
{
    list->updateContent();
}

void GroupInformationComponent::valueTreeChildrenChanged (ValueTree& treeWhoseChildHasChanged)
{
    list->updateContent();
}

void GroupInformationComponent::valueTreeParentChanged (ValueTree& treeWhoseParentHasChanged)
{
    list->updateContent();
}

//==============================================================================
class FileOptionComponent  : public Component
{
public:
    FileOptionComponent (const Project::Item& item_)
        : item (item_), compileButton (0), resourceButton (0)
    {
        if (item.isFile())
        {
            addAndMakeVisible (compileButton = new ToggleButton ("Compile"));
            compileButton->getToggleStateValue().referTo (item.getShouldCompileValue());

            addAndMakeVisible (resourceButton = new ToggleButton ("Add to Binary Resources"));
            resourceButton->getToggleStateValue().referTo (item.getShouldAddToResourceValue());
        }
    }

    ~FileOptionComponent()
    {
        deleteAllChildren();
    }

    void paint (Graphics& g)
    {
        int x = getHeight() + 6;
        Image* icon = item.getIcon();

        if (icon != 0)
        {
            g.drawImageWithin (icon, 2, 2, x - 4, getHeight() - 4,
                               RectanglePlacement::centred | RectanglePlacement::onlyReduceInSize,
                               false);

            ImageCache::release (icon);
        }

        g.setColour (Colours::black);
        g.setFont (getHeight() * 0.6f);

        const int x2 = compileButton == 0 ? getWidth() - 4
                                          : compileButton->getX() - 4;

        g.drawText (item.getName().toString(), x, 0, x2 - x, getHeight(), Justification::centredLeft, true);

        g.setColour (Colours::lightgrey);
        g.fillRect (0, getHeight() - 1, getWidth(), 1);
    }

    void resized()
    {
        if (resourceButton != 0)
        {
            int w = 180;
            resourceButton->setBounds (getWidth() - w, 1, w, getHeight() - 2);
            w = 100;
            compileButton->setBounds (resourceButton->getX() - w, 1, w, getHeight() - 2);
        }
    }

    Project::Item item;

private:
    ToggleButton* compileButton;
    ToggleButton* resourceButton;
};

Component* GroupInformationComponent::refreshComponentForRow (int rowNumber, bool isRowSelected, Component* existingComponentToUpdate)
{
    if (rowNumber < getNumRows())
    {
        Project::Item child (item.getChild (rowNumber));

        if (existingComponentToUpdate == 0
             || dynamic_cast <FileOptionComponent*> (existingComponentToUpdate)->item != child)
        {
            delete existingComponentToUpdate;
            existingComponentToUpdate = new FileOptionComponent (child);
        }
    }
    else
    {
        deleteAndZero (existingComponentToUpdate);
    }

    return existingComponentToUpdate;
}
