/* =========================================================================================

   This is an auto-generated file, created by The Jucer V3.0.0
   Do not edit anything in this file!

*/

namespace BinaryData
{
    extern const char*   AudioPluginXCodeScript_txt;
    const int            AudioPluginXCodeScript_txtSize = 1449;

    extern const char*   jucer_AudioPluginEditorTemplate_cpp;
    const int            jucer_AudioPluginEditorTemplate_cppSize = 1003;

    extern const char*   jucer_AudioPluginEditorTemplate_h;
    const int            jucer_AudioPluginEditorTemplate_hSize = 794;

    extern const char*   jucer_AudioPluginFilterTemplate_cpp;
    const int            jucer_AudioPluginFilterTemplate_cppSize = 4349;

    extern const char*   jucer_AudioPluginFilterTemplate_h;
    const int            jucer_AudioPluginFilterTemplate_hSize = 2353;

    extern const char*   jucer_MainConsoleAppTemplate_cpp;
    const int            jucer_MainConsoleAppTemplate_cppSize = 749;

    extern const char*   jucer_MainTemplate_cpp;
    const int            jucer_MainTemplate_cppSize = 2106;

    extern const char*   jucer_NewCppFileTemplate_cpp;
    const int            jucer_NewCppFileTemplate_cppSize = 232;

    extern const char*   jucer_NewCppFileTemplate_h;
    const int            jucer_NewCppFileTemplate_hSize = 308;

    extern const char*   jucer_WindowTemplate_cpp;
    const int            jucer_WindowTemplate_cppSize = 794;

    extern const char*   jucer_WindowTemplate_h;
    const int            jucer_WindowTemplate_hSize = 1290;

    extern const char*   juce_icon_png;
    const int            juce_icon_pngSize = 19826;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
