/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

namespace BinaryData
{
    extern const char*   cello_wav;
    const int            cello_wavSize = 46348;

    extern const char*   demo_table_data_xml;
    const int            demo_table_data_xmlSize = 5239;

    extern const char*   icons_zip;
    const int            icons_zipSize = 83876;

    extern const char*   juce_png;
    const int            juce_pngSize = 15290;

    extern const char*   treedemo_xml;
    const int            treedemo_xmlSize = 1126;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
