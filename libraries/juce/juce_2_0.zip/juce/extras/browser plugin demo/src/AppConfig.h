
#include "BrowserPluginCharacteristics.h"