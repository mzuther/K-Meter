/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#ifndef BINARYDATA_H_62491730_INCLUDED
#define BINARYDATA_H_62491730_INCLUDED

namespace BinaryData
{
    extern const char*   AudioPluginXCodeScript_txt;
    const int            AudioPluginXCodeScript_txtSize = 2916;

    extern const char*   background_tile_png;
    const int            background_tile_pngSize = 151;

    extern const char*   colourscheme_dark_xml;
    const int            colourscheme_dark_xmlSize = 1050;

    extern const char*   colourscheme_light_xml;
    const int            colourscheme_light_xmlSize = 1050;

    extern const char*   jucer_AudioPluginEditorTemplate_cpp;
    const int            jucer_AudioPluginEditorTemplate_cppSize = 1008;

    extern const char*   jucer_AudioPluginEditorTemplate_h;
    const int            jucer_AudioPluginEditorTemplate_hSize = 799;

    extern const char*   jucer_AudioPluginFilterTemplate_cpp;
    const int            jucer_AudioPluginFilterTemplate_cppSize = 4640;

    extern const char*   jucer_AudioPluginFilterTemplate_h;
    const int            jucer_AudioPluginFilterTemplate_hSize = 2488;

    extern const char*   jucer_ComponentTemplate_cpp;
    const int            jucer_ComponentTemplate_cppSize = 2083;

    extern const char*   jucer_ComponentTemplate_h;
    const int            jucer_ComponentTemplate_hSize = 2156;

    extern const char*   jucer_ContentCompTemplate_cpp;
    const int            jucer_ContentCompTemplate_cppSize = 886;

    extern const char*   jucer_ContentCompTemplate_h;
    const int            jucer_ContentCompTemplate_hSize = 924;

    extern const char*   jucer_InlineComponentTemplate_h;
    const int            jucer_InlineComponentTemplate_hSize = 1143;

    extern const char*   jucer_MainConsoleAppTemplate_cpp;
    const int            jucer_MainConsoleAppTemplate_cppSize = 470;

    extern const char*   jucer_MainTemplate_NoWindow_cpp;
    const int            jucer_MainTemplate_NoWindow_cppSize = 1947;

    extern const char*   jucer_MainTemplate_Window_cpp;
    const int            jucer_MainTemplate_Window_cppSize = 3613;

    extern const char*   jucer_NewComponentTemplate_cpp;
    const int            jucer_NewComponentTemplate_cppSize = 1389;

    extern const char*   jucer_NewComponentTemplate_h;
    const int            jucer_NewComponentTemplate_hSize = 648;

    extern const char*   jucer_NewCppFileTemplate_cpp;
    const int            jucer_NewCppFileTemplate_cppSize = 262;

    extern const char*   jucer_NewCppFileTemplate_h;
    const int            jucer_NewCppFileTemplate_hSize = 308;

    extern const char*   jucer_NewInlineComponentTemplate_h;
    const int            jucer_NewInlineComponentTemplate_hSize = 1626;

    extern const char*   RecentFilesMenuTemplate_nib;
    const int            RecentFilesMenuTemplate_nibSize = 2842;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Number of elements in the namedResourceList array.
    const int namedResourceListSize = 22;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}

#endif
